def send_header():
    print("Status: 200 OK")
    print("Content-Type: application/json; charset=UTF-8")
