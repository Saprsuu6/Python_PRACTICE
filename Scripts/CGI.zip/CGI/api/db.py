conf = {
    "host":     "localhost",
    "port":     3306,
    "database": "py191",
    "user":     "py191_user",
    "password": "pass_191",

    "charset":  "utf8mb4",
    "use_unicode": True,
    "collation": "utf8mb4_general_ci"
}
